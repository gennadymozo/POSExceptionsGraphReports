﻿//  "use strict";
require(['jquery', 'knockout'], function($, ko) {
    var _tag = 'app.tool-util.xtras.ko-sort-util', _lnum = 'app.tool-util.xtras.ko-sort-util', self = this;
    try {
         self.ko_sort_hub = function(_vm, _id, _class) {
            let _arr = _id.split("|")[0], _field = _id.split("|")[1], _direction = _class.split(' ')[1], _data_type = _class.split(' ')[2];
            let dollars2number = function(b) { if(b === undefined) { return }; return Number(b.replace(",", "").replace("$", "").replace(".", "")); }
            let time2seconds = function(a) { if(a === undefined) { return }; return ((Number((a.split(' ')[0].split(':')[0] * 60 * 60)) + Number((a.split(' ')[0].split(':')[1] * 60)) + Number((a.split(' ')[0].split(':')[2]))) + Number((a.split(' ')[1] == 'PM' ? 3600 * 12 : 1))); }
            try {
                if(_data_type == '_time') {
                    if(_direction == 'down') { eval("_vm." + _arr + ".sort(function(left, right) { return left." + _field + " == right." + _field + " ? 0 : (time2seconds(left." + _field + ") < time2seconds(right." + _field + ") ? 1 : -1) })") };
                    if(_direction == 'up') { eval("_vm." + _arr + ".sort(function(left, right) { return left." + _field + " == right." + _field + " ? 0 : (time2seconds(left." + _field + ") < time2seconds(right." + _field + ") ? -1 : 1) })") };
                    return (!0);
                }
                if(_data_type == '_money') {
                    if(_direction == 'down') { eval("_vm." + _arr + ".sort(function(left, right) { return left." + _field + " == right." + _field + " ? 0 : (dollars2number(left." + _field + ") < dollars2number(right." + _field + ") ? 1 : -1) })") };
                    if(_direction == 'up') { eval("_vm." + _arr + ".sort(function(left, right) { return left." + _field + " == right." + _field + " ? 0 : (dollars2number(left." + _field + ") < dollars2number(right." + _field + ") ? -1 : 1) })") };
                    return (!0);
                }
                if(_direction == 'down' ) { eval("_vm." + _arr + ".sort(function(left, right) { return left." + _field + " == right." + _field + " ? 0 : (left." + _field + " < right." + _field + " ? 1 : -1) })") };
                if(_direction == 'up'   ) { eval("_vm." + _arr + ".sort(function(left, right) { return left." + _field + " == right." + _field + " ? 0 : (left." + _field + " < right." + _field + " ? -1 : 1) })") };
             } catch(e) { console.log(e.message) }
             return (!0);
        }
    } catch(e) { console.log(e.name + '\n' + _tag + ' : _lnum : ' + _lnum + '\n' + e.message); }
    return (self);
});


//  how to use:

//  *.js
//    $('.arrow').on('click', function() { ko_sort_hub($(this).parent().attr('id'), $(this).attr('class') ) });


//  *.html
//    <div id="report-div-variance-" class="-report-div-">
//        <span class="-data-length-" style="font-size: .8em!important;font-family: Verdana,Arial,sans-serif;" data-bind="text: $root.rep_table_variance_data().length + '  lines'"></span>
//        <table id="report-table-variance-" class="-report-table-trx-">
//            <thead>
//                <tr>
//                    <th id="rep_table_variance_data|Posistion">Reg				<span title="asc" class="arrow up"></span>&nbsp;&nbsp;&nbsp;<span title="desc" class="arrow down"></span></th>
//                    <th id="rep_table_variance_data|TransData">Register Data	    <span title="asc" class="arrow up"></span>&nbsp;&nbsp;&nbsp;<span title="desc" class="arrow down"></span></th>
//                    <th id="rep_table_variance_data|TimeStamp">Time Stamp		    <span title="asc" class="arrow up _time"></span>&nbsp;&nbsp;&nbsp;<span title="desc" class="arrow down _time"></span></th>
//                    <th id="rep_table_variance_data|TicketNum">Ticket Num		    <span title="asc" class="arrow up"></span>&nbsp;&nbsp;&nbsp;<span title="desc" class="arrow down"></span></th>
//                    <th id="rep_table_variance_data|Cashier">Cashier			    <span title="asc" class="arrow up"></span>&nbsp;&nbsp;&nbsp;<span title="desc" class="arrow down"></span></th>
//                    <th id="rep_table_variance_data|SmartDrawerActualBalance">Drawer Balance	    <span title="asc" class="arrow up _money"></span>&nbsp;&nbsp;&nbsp;<span title="desc" class="arrow down _money"></span></th>
//                    <th id="rep_table_variance_data|CurrentCashDifference">Current Diff	        <span title="asc" class="arrow up _money"></span>&nbsp;&nbsp;&nbsp;<span title="desc" class="arrow down _money"></span></th>
//                    <th id="rep_table_variance_data|TotalCashDifference">Total Diff		        <span title="asc" class="arrow up _money"></span>&nbsp;&nbsp;&nbsp;<span title="desc" class="arrow down _money"></span></th>
//                    <th id="rep_table_variance_data|SafeDeposit">Safe Total		                <span title="asc" class="arrow up _money"></span>&nbsp;&nbsp;&nbsp;<span title="desc" class="arrow down _money"></span></th>
//                </tr>
//            </thead>
//            <tbody data-bind="foreach: $root.rep_table_variance_data">
//                <tr>
//                    <td data-bind="text: Posistion                 "></td>
//                    <td data-bind="html: TransData                 "></td>
//                    <td data-bind="text: TimeStamp                 "></td>
//                    <td data-bind="text: TicketNum                 "></td>
//                    <td data-bind="text: Cashier                   "></td>
//                    <td data-bind="text: SmartDrawerActualBalance, style: { color: SmartDrawerActualBalance.includes('-') ? '#FF0000' : '#000000' }"></td>
//                    <td data-bind="text: CurrentCashDifference, style: { color: CurrentCashDifference.includes('-') ? '#FF0000' : '#000000' }"></td>
//                    <td data-bind="text: TotalCashDifference, style: { color: TotalCashDifference.includes('-') ? '#FF0000' : '#000000' }"></td>
//                    <td data-bind="text: SafeDeposit, style: { color: SafeDeposit.includes('-') ? '#FF0000' : '#000000' }"></td>
//                </tr>
//            </tbody>
//        </table>
//    </div>

//  .arrow {
//      border: solid white;
//      border-width: 0 3px 3px 0;
//      display: inline-block;
//      padding: 3px;
//      cursor: grabbing;
//  }
//  .up {
//      transform: rotate(-135deg);
//      -webkit-transform: rotate(-135deg);
//      margin-left: 1em;
//  }
//  
//  .down {
//      transform: rotate(45deg);
//      -webkit-transform: rotate(45deg);
//      margin-left: .2em;
//  }
//  .right {
//      transform: rotate(-45deg);
//      -webkit-transform: rotate(-45deg);
//  }
//  
//  .left {
//      transform: rotate(135deg);
//      -webkit-transform: rotate(135deg);
//  }
//  
