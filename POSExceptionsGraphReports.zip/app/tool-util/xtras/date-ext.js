require(["jquery", "knockout", "jquery-ui"], function(e, t) {
    try {
        var a = this;
        a._weekNum = function(e) {
            e = new Date(e);
            var t = new Date(e.valueOf()),
                a = (e.getDay() + 6) % 7;
            t.setDate(t.getDate() - a + 3);
            var n = new Date(t.getFullYear(), 0, 4),
                r = new Date(n).getFullYear(),
                s = (t - n) / 864e5,
                o = 1 + Math.ceil(s / 7);
            return r + "" + (o = o < 10 ? "0" + o : o)
        };
        a._applyAfter = function() {
            e(".-pick-date-").each(function() {
                e(this).hasClass("hasDatepicker") && e(this).removeClass("hasDatepicker"), e(this).datepicker({
                    firstDay: 1,
                    autoOpen: !1,
                    showOtherMonths: !0,
                    selectOtherMonths: !0,
                    changeMonth: !0,
                    changeYear: !0,
                    dateFormat: "mm/dd/yy",
                    stepMonths: 0,
                    showAnim: "slideDown",
                    minDate: "-60M",
                    maxDate: _getMaxDate()
                })
            })
        }, a._applyAfterAdd = function(t) {
            e(".-activity-date-").each(function() {
                e(this).hasClass("hasDatepicker") && e(this).removeClass("hasDatepicker"), e(this).datepicker({
                    firstDay: 1,
                    autoOpen: !0,
                    showOtherMonths: !0,
                    selectOtherMonths: !0,
                    changeMonth: !1,
                    changeYear: !1,
                    dateFormat: "mm/dd/yy",
                    stepMonths: 0,
                    defaultDate: new Date(t),
                    beforeShow: function(e, t) { },
                    beforeShowDay: function(e) {
                        var a = new Date(t);
                        a.setHours(0, 0, 0, 0), a.setDate(a.getDate() + 1 - (a.getDay() || 7));
                        var n = new Date(a);
                        return n.setDate(a.getDate() + 6), [e >= a && e <= n, ""]
                    },
                    showAnim: "slideDown"
                })
            })
        }, a._isDate = function(e) {
            return "" != e && new Date(e) instanceof Date
        }, a._weekByDateParams = function(e, t) {
            var n = new Date(t);
            n.setHours(0, 0, 0, 0), n.setDate(n.getDate() + 1 - (n.getDay() || 7));
            var r = new Date(n);
            return r.setDate(n.getDate() + 6), {
                userName: e,
                dateFrom: a._dateShort(n),
                dateTo: a._dateShort(r)
            }
        }, a._dateMinusWeek = function(e) {
            var t = new Date(e);
            return t.setHours(0, 0, 0, 0), t.setDate(t.getDate() - 7), t.setDate(t.getDate() + 1 - (t.getDay() || 7)), new Date(t)
        }, a._today = function() {
            var e = new Array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"),
                t = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"),
                a = new Date;
            return e[a.getDay()] + ", " + t[a.getMonth()] + " " + a.getDate() + ", " + a.getFullYear()
        }, a.showWeek = function() {
            e("#welcome-div-").hide(), e("#week-summary-hdr-").show("fade", {
                duration: 1e3
            }), e("#week-summary-dtl-").show("fade", {
                duration: 1e3
            })
        }
    } catch(e) {
        alert(e.name + "\ndate-ext : _lnum : 0\n" + e.message)
    }
    return a
});