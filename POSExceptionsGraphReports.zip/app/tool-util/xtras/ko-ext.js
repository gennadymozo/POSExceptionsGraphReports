﻿//   @formatter:off
"use strict";
require(['jquery', 'knockout']
    , function($, ko) {
        var _tag = 'ko-ext', _lnum = 0;
        try {
            ko.bindingHandlers.date_picker = {
                init: function(element, valueAccessor, allBindingsAccessor) {
                    //initialize datepicker with some optional options
                    var options = allBindingsAccessor().datepickerOptions || {};
                    $(element).datepicker(options);

                    //handle the field changing
                    ko.utils.registerEventHandler(element, "change", function() {
                        var observable = valueAccessor();
                        observable($(element).datepicker("getDate"));
                    });

                    //handle disposal (if KO removes by the template binding)
                    ko.utils.domNodeDisposal.addDisposeCallback(element, function() {
                        $(element).datepicker("destroy");
                    });

                },
                //update the control when the view model changes
                update: function(element, valueAccessor) {
                    var value = ko.utils.unwrapObservable(valueAccessor()),
                        current = $(element).datepicker("getDate");

                    if(value - current !== 0) {
                        $(element).datepicker("setDate", value);
                    }
                }
            };
            ko.bindingHandlers.datepicker = {
                init: function(element, valueAccessor, allBindingsAccessor) {
                    var $el = $(element);

                    //initialize datepicker with some optional options
                    var options = allBindingsAccessor().datepickerOptions || {};
                    $el.datepicker(options);

                    //handle the field changing
                    ko.utils.registerEventHandler(element, "change", function() {
                        var observable = valueAccessor();
                        observable($el.datepicker("getDate"));
                    });

                    //handle disposal (if KO removes by the template binding)
                    ko.utils.domNodeDisposal.addDisposeCallback(element, function() {
                        $el.datepicker("destroy");
                    });

                },
                update: function(element, valueAccessor) {
                    var value = ko.utils.unwrapObservable(valueAccessor()),
                        $el = $(element),
                        current = $el.datepicker("getDate");

                    if(value - current !== 0) {
                        $el.datepicker("setDate", value);
                    }
                }
            };
            
            ko.extenders.required = function(target, overrideMessage) {
                target.hasError = ko.observable();
                target.validationMessage = ko.observable();
                function validate(newValue) {
                    target.hasError(newValue ? false : true);
                    target.validationMessage(newValue ? '' : overrideMessage || 'This field is required');
                    //if (target.hasError()) {
                    //    alert('f(gm)');
                    //};
                }
                validate(target());
                target.subscribe(validate);
                return target;
            };

            ko.extenders.numeric = function(target, precision) {
                var result = ko.computed({
                    read: target,
                    write: function(newValue) {
                        var current = target(),
                            roundingMultiplier = Math.pow(10, precision),
                            newValueAsNum = isNaN(newValue) ? 0 : parseFloat(+newValue),
                            valueToWrite = Math.round(newValueAsNum * roundingMultiplier) / roundingMultiplier;
                        if(valueToWrite !== current) {
                            target(valueToWrite);
                        } else {
                            if(newValue !== current) {
                                target.notifySubscribers(valueToWrite);
                            }
                        }
                    }
                });
                result(target());
                return result;
            };

            ko.unbindScopeNode = function(_node, remove) {
                _node.find("*").each(function() {
                    $(this).unbind();
                });
                if(remove) {
                    ko.removeNode($node[0]);
                } else {
                    ko.cleanNode($node[0]);
                }
            };

            ko.cleanScope = function(_vm2apply, _element) {
                ko.cleanNode($(_element)[0]);
                ko.applyBindings(_vm2apply, $(_element)[0]);
            }

            ko.observableArray.fn.pushAllEx = function(valuesToPush, replace) {
                try {
                    //  var underlyingArray = this();
                    //  this.valueWillMutate();
                    //  ko.utils.arrayPushAll(underlyingArray, valuesToPush);
                    //  this.valueHasMutated();

                    var underlyingArray = this();
                    this.valueWillMutate();
                    if(replace)
                        underlyingArray.splice(0, underlyingArray.length);

                    if(valuesToPush instanceof Array) {
                        underlyingArray.push.apply(underlyingArray, valuesToPush);
                    }
                    else {
                        for(var i = 0, j = valuesToPush.length; i < j; i++)
                            underlyingArray.push(valuesToPush[i]);
                    }
                    this.valueHasMutated();
                } catch(e) { ; }
                return this;  //just in case - optional
            };
            ko.observableArray.fn.refresh = function(item) {
                var index = this['indexOf'](item);
                if(index >= 0) {
                    this.splice(index, 1);
                    this.splice(index, 0, item);
                }
            }
        } catch(e) { alert(e.name + '\n' + _tag + ' : _lnum : ' + _lnum + '\n' + e.message); }
        return (this);
    });




            //ko.bindingHandlers.singleClick = {
            //    init: function(element, valueAccessor) {
            //        var handler = valueAccessor(),
            //            delay = 400,
            //            clickTimeout = false;

            //        $(element).click(function() {
            //            if(clickTimeout !== false) {
            //                clearTimeout(clickTimeout);
            //                clickTimeout = false;
            //            } else {
            //                clickTimeout = setTimeout(function() {
            //                    clickTimeout = false;
            //                    handler();
            //                }, delay);
            //            }
            //        });
            //    }
            //};



/*
            Array.prototype.clear = function () {
                while (this.length > 0) {
                    this.pop();
                }
            };
            Number.prototype.isInt= function(){
                    return this== this>> 0;
            };
        
        
            ko.observableArray.fn.gSort = function(fld, direction)
            {
                var isDesc = direction && direction.toLowerCase() == 'desc';
        
                return ko.observableArray(this.sort(function (a, b) {
                    a = ko.unwrap(a[fld]);
                    b = ko.unwrap(b[fld]);
        
                    return (a == b ? 0 : a < b ? -1 : 1) * (isDesc ? -1 : 1);
                    }));
            };
        */






/*
Date.prototype.getWeek = function() {
    var jan = new Date(this.getFullYear(),0,1);
    var n = Math.ceil((((this - jan) / 86400000) + jan.getDay()+1)/7);
    return n<10?'0'+n:n;
}
*/
/*
Array.prototype.clone = function (doDeepCopy) {
    if (doDeepCopy) {
        var encountered = [{
            a: this,
            b: []
        }];

        var item,
            levels = [{ a: this, b: encountered[0].b, i: 0 }],
            level = 0,
            i = 0,
            len = this.length;

        while (i < len) {
            item = levels[level].a[i];
            if (Object.prototype.toString.call(item) === '[object Array]') {
                for (var j = encountered.length - 1; j >= 0; j--) {
                    if (encountered[j].a === item) {
                        levels[level].b.push(encountered[j].b);
                        break;
                    }
                }
                if (j < 0) {
                    encountered.push(j = {
                        a: item,
                        b: []
                    });
                    levels[level].b.push(j.b);
                    levels[level].i = i + 1;
                    levels[++level] = { a: item, b: j.b, i: 0 };
                    i = -1;
                    len = item.length;
                }
            }
            else {
                levels[level].b.push(item);
            }

            if (++i == len && level > 0) {
                levels.pop();
                i = levels[--level].i;
                len = levels[level].a.length;
            }
        }

        return encountered[0].b;
    }
    else {
        return this.slice(0);
    }
};
*/
//Array.prototype.clone = function () {
//    return this.slice(0);
//};

//http://knockoutjs.com/documentation/plugins-mapping.html

//    function cloneObservable(observableObject) {
//        return ko.mapping.fromJS(ko.toJS(observableObject));
//    }
//http://api.jquery.com/jQuery.extend/
// Merge object2 into object1
//$.extend(object1, object2);
//// Shallow copy
//var newObject = jQuery.extend({}, oldObject);

//// Deep copy
//var newObject = jQuery.extend(true, {}, oldObject);



//  http://jsfiddle.net/s2bLv/4/
//<div id='text'>Hi</div>
//function Person(){}
//Person.prototype.favorite_books = [];

//$('#text').text('alright');

//var george = new Person();
//george.favorite_books = ['Curious George'];

//var kate = new Person();
//kate.favorite_books = ['The Da Vinci Code', 'Harry Potter'];

//var people = [kate, george];
//var people_copy = [];
//$.each(people,function(i,obj) {
//    people_copy.push($.extend(true,{},obj)); 
//});
//people_copy[0].favorite_books[0] = 'Ender's Game';

//$('#text').text('working');
//$('#text').text(people[0].favorite_books[0]);
