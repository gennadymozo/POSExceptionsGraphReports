define(["jquery"], function(t) {
    try {
        this.arrayToTable = function(e, a) {
            var n, o, p, r, h = t("<table />"),
                l = [];
            a = t.extend({
                th: !0,
                thead: !1,
                tfoot: !1,
                attrs: {}
            }, a), h.attr(a.attrs);
            var d = 0;
            if(null == e[0].length && t.each(e, function(e, n) {
                p = t("<tr />"), Object.keys(n).forEach(function(e) {
                    0 == d && a.th ? p.append(t("<th />").html(e)) : p.append(t("<td />").html(n[e]))
                }), l.push(p), d++
            }), e[0].length > 0)
                for(d = 0; d < e.length; d++) {
                    for(p = t("<tr />"), r = 0; r < e[d].length; r++) 0 == d && a.th ? p.append(t("<th />").html(e[d][r])) : p.append(t("<td />").html(e[d][r]));
                    l.push(p)
                }
            for(a.thead && (n = l.shift(), n = t("<thead />").append(n), h.append(n)), a.tfoot && (o = l.pop()), d = 0; d < l.length; d++) h.append(l[d]);
            return a.tfoot && (o = t("<tfoot />").append(o), h.append(o)), a.title && (title = t("<h3 />"), h.prepend(o)), h
        }
    } catch(t) {
        return console.log(t.name + "\napp.tool-util.xtras.array2table self.arrayToTable = function(data, options)  0\n" + t.message), !0
    }
    return this
});