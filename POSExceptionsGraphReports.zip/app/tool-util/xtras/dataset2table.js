﻿define(["jquery"], function(e) {
    try {
        this.dataset2table = function(e, t) {
            null == t && (t = function(e) {
                alert("link to exec storekeeper undefined")
            }), console.log(document.getElementsByClassName("gridtable")), document.getElementsByClassName("gridtable"), console.log(document.getElementById("popup-table-")), document.getElementById("popup-table-");
            var n = document.createElement("table");
            n.className = "gridtable";
            var a = document.createElement("thead"),
                d = document.createElement("tbody"),
                l = document.createElement("tr"),
                o = [];
            if(e.length > 0) {
                var r = e[0];
                for(var c in r) o.push(c)
            }
            return o.forEach(function(e) {
                var t = document.createElement("th");
                "storekeeperUrl" == e && t.setAttribute("hidden", !0), t.appendChild(document.createTextNode(e)), l.appendChild(t)
            }), a.appendChild(l), n.appendChild(a), e.forEach(function(e) {
                var t = document.createElement("tr");
                for(var n in e) {
                    if(e[n] = e[n].slice(1, -1), e[n].includes("storekeeper://")) {
                        console.log(e[n]), e[n] = decodeURIComponent(e[n]), console.log(e[n]);
                        document.createElement("input");
                        var a = document.createElement("a"),
                            l = document.createTextNode(" ");
                        a.setAttribute("hidden", !0), a.innerText = "Go there", a.appendChild(l), o.appendChild(a), t.appendChild(o)
                    }
                    if(!e[n].includes("storekeeper://")) {
                        var o = document.createElement("td");
                        o.appendChild(document.createTextNode(e[n])), t.appendChild(o)
                    }
                }
                d.appendChild(t)
            }), n.appendChild(d), n
        }
    } catch(e) {
        return console.log(e.name + "\napp.tool-util.xtras.dataset2table self.dataset2table = function(data)  0\n" + e.message), !0
    }
    return this
});