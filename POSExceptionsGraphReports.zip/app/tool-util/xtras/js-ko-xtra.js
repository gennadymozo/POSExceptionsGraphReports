//  "use strict";
require(["jquery", "knockout"], function($, ko) {
    var $$$DEBUG = !1,
        _tag = "js-ko-xtra",
        self = this;
    return self.canvasLayerContex = function(r, a) {
        return this.width = $(window).width(), this.height = $(window).height(), this.element = document.createElement("canvas"), $(this.element).attr("id", a).text("unsupported browser").width(this.width).height(this.height).appendTo(r), this.context = this.element.getContext("2d"), this.context
    }, self.canvasLayer = function(r, a) {
        try {
            document.removeChild(document.getElementById(a))
        } catch(r) { }
        this.width = $(window).width(), this.height = $(window).height(), this.element = document.createElement("canvas"), $(this.element).attr("id", a).addClass("my-class").text("unsupported browser").width(this.width).height(this.height).appendTo(r)
    }, self._meta2strip_arr = function(_meta, _arr) {
        for(var __marr = eval(_meta.split(",")), _n, i = 0; i < __marr.length; i++) {
            _n = __marr[i].split(":")[0].replace(/"/g, "").replace(/\\/g, "").trim();
            try {
                $$$DEBUG && console.log("_meta2strip_arr __marr. eval " + _n + '="' + eval('_arr["' + _n + '"]') + '"\n'), eval("__marr." + _n + '="' + eval('_arr["' + _n + '"]') + '"')
            } catch(r) {
                $$$DEBUG && alert(r.name + "\n ->_meta2strip_arr \n" + r.message)
            }
        }
        return $$$DEBUG && console.log("_meta2strip_arr ->__marr:\n" + __marr + "\n"), __marr
    }, self._is_param = function(_metadata, _arr, _param) {
        try {
            return eval("_metadata." + _param + "=_arr." + _param), !0
        } catch(r) {
            return !1
        }
    }, self._this2array = function(_metadata, _this, _arr) {
        var m = _metadata,
            ar, n;
        m = JSON.stringify(ko.toJS(m), null, 2).replace(/[\[\]&]+/g, "").replace(/[{}]/gi, "").trim(), ar = m.split(",");
        for(var i = 0; i < ar.length; i++) {
            n = ar[i].split(":")[0].replace(/"/g, "").replace(/\\/g, "").trim();
            try {
                $$$DEBUG && console.log("_this2array->    _arr." + n + "=this._" + n + ".peek();  -> arr.value (n) = " + eval("(_arr." + n + ")") + "\n"), eval("_arr." + n + "=this._" + n + ".peek();")
            } catch(r) {
                $$$DEBUG && alert(r.name + "\n >_this2array \n" + r.message)
            }
        }
        return $$$DEBUG && console.log("_this2array (return (_arr)):\n " + JSON.stringify(_arr) + "\n"), _arr
    }, self._array2this = function(_metadata, _this, _arr) {
        var m = _metadata,
            ar, n;
        m = JSON.stringify(ko.toJS(m), null, 2).replace(/[\[\]&]+/g, "").replace(/[{}]/gi, "").trim(), ar = m.split(",");
        for(var i = 0; i < ar.length; i++) {
            n = ar[i].split(":")[0].replace(/"/g, "").replace(/\\/g, "").trim();
            try {
                $$$DEBUG && console.log("_array2this->    this._" + n + "(_arr." + n + ");   -> arr.value (n) = " + eval("(_arr." + n + ")") + "\n"), eval("this._" + n + "(_arr." + n + ");")
            } catch(r) {
                $$$DEBUG && alert(r.name + "\n >_array2this \n" + r.message)
            }
        }
    }, self._clean2this = function(_metadata, _this) {
        var m = _metadata,
            ar, n;
        m = JSON.stringify(ko.toJS(m), null, 2).replace(/[\[\]&]+/g, "").replace(/[{}]/gi, "").trim(), ar = m.split(",");
        for(var i = 0; i < ar.length; i++) {
            n = ar[i].split(":")[0].replace(/"/g, "").replace(/\\/g, "").trim();
            try {
                $$$DEBUG && console.log("_clean2this->    this._" + n + '("");'), eval("this._" + n + '("");')
            } catch(r) {
                $$$DEBUG && alert(r.name + "\n >_clean2this \n" + r.message)
            }
        }
    }, self
});