"use strict";
define(["jquery"], function(n) {
    var e = [];
    return {
        createPlugin: function(t, u) {
            var r = n.extend({}, u);
            return r.register = function() { ! function(n, t) {  e[n] = t }(t, r) }, r
        },
        unregisterPlugin: function(n) {
            ! function(n) { null != e[n] && delete e[n] }(n)
        }
    }
});