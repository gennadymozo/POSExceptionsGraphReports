"use strict";
define(["jquery", "xml2json"], function(e) {
    var r = {
            url: "../DbSupport/DbHub.aspx/DbHubProcess",
            success: void 0,
            error: void 0,
            parameters: "",
            data: {},
            type: "POST",
            async: !0,
            dataType: "json"
        },
        t = function(t) {
            var n = this,
                s = function(r, n, s) {
                    return e.blockUI(), console.log("interop: error\n " + r + "\n interop:" + s + "\n" + n + "\n data: \n" + JSON.stringify(t)), !0
                };
            n._options = null, n._init = function() {
                try {
                    n._options = e.extend(!0, {}, r, t)
                } catch (r) { return e.blockUI(), s(r.name, r.message, "(11;)"), !0 }
            }, n.invoke = function() {
                var r = e.extend(!0, {}, null, {
                    parameters: n._options.parameters
                });
                try {
                    0;
                    e.ajax({
                        type: "POST",
                        url: "" == n._options.url ? n._defaults.url : n._options.url,
                        data: JSON.stringify(r),
                        contentType: "application/json; charset=utf-8",
                        dataType: "json",
                        success: function(r) {
                            var t = {},
                                a = [],
                                o = {};
                            if ("" == r.d) return o = {
                                _datasets: a
                            }, n._options.success(o, n), !0;
                            try {
                                t = JSON.parse(r.d)
                            } catch (e) { t = r.d }
                            try {
                                if (t.ERROR) return n._options.error("48", t.ERROR, "sql server", n), void console.log(t.ERROR);
                                if(t.SUCCESS) return void n._options.success(t, n);
                            } catch (e) {}
                            if (t) try {
                                t = "<d>" + (t = t.replace(/~/g, "").replace("{Table:[{XML_F52E2B61-18A1-11d1-B105-00805F49916B:", "").replace("}]}", "")) + "</d>";
                                var c = xml2json(e.parseXML(t), "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&apos;/g, "'").replace(/&quot;/g, '"').replace(/&nbsp;/g, " ").replace(/&copy;/g, "@").replace(/&reg;/g, "?");
                                null != (t = JSON.parse(c).d)._datasets && (null != t._datasets[0] && (o = t), null == t._datasets[0] && (a.push(t._datasets), o = {
                                    _datasets: a
                                })), null == t._datasets && (o = t)
                            } catch (e) { s(e.name, e.message, "if(_use_microsoft_) (22;)") }
                            n._options.success(o, n)
                        },
                        error: function(e, r, t) {
                            console.log("errorFn = function(jqXHR, statusText, error)\n" + JSON.stringify(e) + "\n" + JSON.stringify(r) + "\n" + JSON.stringify(t)), n._options.error(e, r, t, n)
                        }
                    })
                } catch (r) { return e.blockUI(), s(r.name, r.message, "(2;)"), !0 }
            };
            try {
                n._init()
            } catch (r) {  return e.blockUI(), s(r.name, r.message, "(4;)"), !1  }
        };
    return { invoke: function(e) { return new t(e).invoke() } }
});