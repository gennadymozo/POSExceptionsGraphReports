﻿"use strict";
require(['global', 'jquery', 'knockout', 'ko-ext', 'js-ko-xtra', 'core-ui', 'serviceHub', 'bootstrap-multiselect', 'blockUI', 'jquery-ui', 'meta-static', 'meta-sp', 'chart', 'chart-ext', 'chart-core', 'popup-table-map']
    , function(G, $, ko, koxtra, jskoxtra, core_ui, serviceHub) {
        var b_flag = !0, $$$DEBUG = !1, _tag = 'data-main', _lnum = 0, vm_main = {}, deselectAll = 'Deselect all';
        $.blockUI();
        $(document).ajaxStart($.blockUI).ajaxStop($.unblockUI); //  , _CHR = 'ег'; //  var _EL = 'е$г', _NV = 'ег', SEP = ' ';
        var DVR_exra = [deselectAll],
            ACTIVE_REPORT_NAME = '',
            WEIGHT_FACTOR_ARR = [],
            REPORT = 'report',
            _cb_empty = function(a) { $.unblockUI },
            _cb_error = function(jqXHR, statusText, error) { $.unblockUI; console.log('statusText, jqXHR.status, error \n' + statusText + ' , ' + jqXHR.status + ' , ' + error)};
        function p_xtra(n, c, o, r, e, t, u, _) {
            try {
                serviceHub.proc_json({parameters: n }
                    , function(n) { !function(n) { c(n, o, r, e, t, u) }(n) }, function(n, c, o) { $.unblockUI, console.log('p_xtra ERROR:\n' + n + '\n' + c + '\n' + o); })
            } catch(n) { return $.unblockUI, console.log('p_xtra (_dbx) \n' + n.name + "\n" + n.message), !0}
        }
        function _proc_main(_pObj, _callback, action, actionType, sub_action, _any, _xtra, _dbx) {
            return void 0 == _dbx && p_xtra(_pObj, _callback, action, actionType, sub_action, _any, _xtra), !0;
            var procResponse = function(response) { _callback(response, action, actionType, sub_action, _any, _xtra, _dbx) };
            try {
                serviceHub.proc_json({ parameters: _pObj , xCall: _dbx }
                    , function(response) { procResponse(response) }, function(a, b, c) { _cb_error(a, b, c); }
                );
            } catch(e) { $.unblockUI; console.log(e.name + '\n' + _tag + ' :< _proc_main = function(result > _lnum : ' + _lnum + '\n' + e.message) }
            ;
        }
        function cb_menu(o, i) {
            try {
                if(o.chart.NoShow) {
                    if(!o.allOnce) {
                        if(1 !== i) return;
                        o.allOnce = !0
                    }
                    o.options.enabled = !0, t.helpers.each(o.pluginTooltips, function(o) {
                        o.initialize(), o._options.bodyFontSize = .02 * o._chart.height, o._options.bodyFontColor = "white", o._options.hoverBackgroundColor = "rgba(225, 0, 55, 0.7)", o._options.border = "1px solid #125215", o._options = 4, o._options = 6, o._options.backgroundColor = "#97A5B3", o.update(), o.pivot(), o.transition(i)[0]
                    }), o.options.enabled = !1
                }
            } catch (e) { console.log(e.message); return !0; }
        }
        $('#login-ok-').on('click', function() {
            if($('#pwd-').val() == '') {
                $('#pwd-req-').html('required field ...');
                $('#pwd-req-').fadeIn();
                return !0;
            }
            _proc_main(['@G1 ifLoginValidateThenMaybe', '@G1 ' + $('#pwd-').val()], function(i) {
                return "FAIL" == i.split("@")[0] ? ($("#pwd-req-").html("invalid password ..."), $("#pwd-req-").fadeIn(), vm_main.__location("Login Fail"), !0) : (vm_main.__location(""), document.getElementById("id01").style.display = "none", $("#body-").fadeIn("300"), vm_main.__location(i.split("@")[0]), i.split("@")[1] && (WEIGHT_FACTOR_ARR = i.split("@")[1].split(",")), !0)});
            return vm_main.__current_obj("ifLoginValidateThenMaybe"), !0;
        });
        function start() {
            if ($('#pwd-').val() == '') {
                $('#pwd-req-').html('required field ...');
                $('#pwd-req-').fadeIn();
                return !0;
            }
            _proc_main(['@G1 ifLoginValidateThenMaybe', '@G1 ' + $('#pwd-').val()], function (i) {
                return "FAIL" == i.split("@")[0] ? ($("#pwd-req-").html("invalid password ..."), $("#pwd-req-").fadeIn(), vm_main.__location("Login Fail"), !0) : (vm_main.__location(""), document.getElementById("id01").style.display = "none", vm_main.__location(i.split("@")[0]), i.split("@")[1] && (WEIGHT_FACTOR_ARR = i.split("@")[1].split(",")), !0)
            });
            return vm_main.__current_obj("ifLoginValidateThenMaybe"), !0;
        }
     try {
        var _vm_main = function(_any) {
            var self = this;
             try {
                self.ev_doAny = function(n) { return ko.computed(function() { return n.doAny() }), this };
                self.__current_obj = ko.observable('G');
                self.ev_block = ko.observable(!0);
                self.__time = ko.observable('March 1, 2016');
                self.__current_title = ko.observable('CB Software, LLC (c)');
                self.__location = ko.observable('somewhere between');
                self.enable_click_go = ko.observable(!1);
                self.enable_panel_proceed = ko.observable(!1);
                self.enable_click_proceed = ko.observable(!0);
                self.enable_check_custom = ko.observable(!0);
                self.enable_panel_custom = ko.observable(!1);
                self.weightFactor = ko.observable(!1);
                self.xCustomReport = ko.observable(!0);                                                 
                self.xWorstSwitch = ko.observable('custom_DVR');                                        
                self.xWorstOptions = ko.observableArray(xOptValues());                                  
                self.xWorstOptions_selected = ko.observable('04');                                      
                self.date_from = ko.observable(new Date('07/18/2020'));                                                       
                self.date_to = ko.observable(new Date());                                               
                self.xReportNames = ko.observableArray(xRepNames());                                    
                self.xReportNames_selected = ko.observable('Exceptions Count By DVR By Date');          
                self.xExceptions = ko.observableArray([]);                                              
                self.xExceptions_selected = ko.observableArray([]);                                     
                self.xDVRs = ko.observableArray([]);                                                    
                self.xDVRs_selected = ko.observableArray([]);                                           
                self.xCashierIDs = ko.observableArray([]);                                              
                self.xCashierIDs_selected = ko.observableArray([]);                                     
                self.xRepImages = ko.observableArray(xImages());                                                   
                self.urlLinks = ko.observableArray([]);
                self.images = ko.observableArray([]); 
                self.popupShowDtl = ko.observable(!1);                                                  
                self.date_range = ko.observable(0);                                                     
                self.url_popup_close = function(_) { document.getElementById('modal-').style.display = 'none' }
                self.url_open = function(item) { document.getElementById('modal-images-').style.display = 'block'; }
                self.urlItems_Click = function(item) { _proc_main(__sp_exec_link_URL('url_open', item._IP_PORT_, item._DATETIME_, item._USER_NAME_, item._XLIST_, item._REF_), _cb_window_open) }
                self.click_go = function(ev) {
                    if(ev == 'NO') return !0;
                    if(ev != 'YES' && (self.date_range() > 10 )) return $('#dialog-confirm-').dialog('open'), !0;
                    self.xDVRs.pushAllEx([], !0);
                    self.xExceptions.pushAllEx([], !0);
                    self.xDVRs_selected([]);
                    self.xExceptions_selected([]);
                    self.enable_click_proceed(!1);
                    $('#click-proceed-').addClass('-disabled-');
                    $('#click-proceed-').attr('disabled', 'disabled');
                    _proc_main(__sp_POSExceptionsGraphReports(void 0, 'code', 'EXC', 'none', self.date_from(), self.date_to()), _proc_comm_cb, 'code', 'exceptions');
                    setTimeout(function() { _proc_main(__sp_POSExceptionsGraphReports(void 0, 'code', 'DVR', 'none', self.date_from(), self.date_to()), _proc_comm_cb, 'code', 'DVR') }, 300);
                }
                self.weightFactor_Click = function(ev) {
                    if(self.xDVRs().length == 0 || self.xExceptions().length == 0) {
                        console.log('No Records Found ( DVR and/or Exceptions )');
                        $.growlUI('No Records Found ( DVR and/or Exceptions )', 'Please change the dates and try again', 400);
                        return !1
                    }
                    return !0
                }
                self.click_proceed = function(ev) {
                    var _action = REPORT,
                        _actionType = self.xReportNames_selected();
                    ACTIVE_REPORT_NAME = '';
                    if(self.xCustomReport() != void 0 && !self.xCustomReport()) {
                        _action = self.xWorstSwitch(), _actionType = 'Worst' + self.xWorstOptions_selected();
                        self.xReportNames_selected(_action == 'custom_DVR' ? 'Exceptions Count By DVR By Date' : 'Exceptions Count By Cashier By Date');
                        _proc_main(__sp_POSExceptionsGraphReports(void 0, _action, _actionType, self.xReportNames_selected(), _dateShort_1(self.date_from()), _dateShort_1(self.date_to()), '', self.xExceptions_selected()), _proc_comm_cb, REPORT, self.xReportNames_selected(), void 0, void 0, "click_proceed");
                        return (!0);
                    }
                    _proc_main(__sp_POSExceptionsGraphReports(void 0, _action, _actionType, self.xReportNames_selected(), _dateShort_1(self.date_from()), _dateShort_1(self.date_to()), self.xDVRs_selected(), self.xExceptions_selected()), _proc_comm_cb, REPORT, self.xReportNames_selected(), void 0, void 0, "click_proceed");
                    return (!0);
                }
                self.xCustomReport_click = function(ev) {
                    $('#click-proceed-').addClass('-disabled-');
                    $('#click-proceed-').attr('disabled', 'disabled');
                    self.enable_panel_custom(!1);
                    self.enable_panel_custom((self.xDVRs().length > 0 && self.xExceptions().length > 0));
                    if(!self.xCustomReport() && (self.xExceptions_selected().length > 0)) {
                        $('#click-proceed-').removeClass('-disabled-');
                        $('#click-proceed-').removeAttr('disabled');
                    }
                    if((self.xExceptions_selected != void 0 && self.xExceptions_selected().length > 0) &&
                        (self.xDVRs_selected != void 0 && self.xDVRs_selected().length > 0)) {
                        $('#click-proceed-').removeClass('-disabled-');
                        $('#click-proceed-').removeAttr('disabled');
                    }
                    if(self.xDVRs().length == 0 || self.xExceptions().length == 0) {
                        console.log('No Records Found ( DVR and/or Exceptions )');
                        $.growlUI('No Records Found ( DVR and/or Exceptions )', 'Please change the dates and try again', 400);
                        return (!1)
                    }
                    if(!self.xCustomReport()) {
                        $('#panel-custom-').fadeIn(400);
                        $('#panel-proceed-').fadeOut(300);
                        return (!0);
                    }
                    $('#panel-custom-').fadeOut(300);
                    $('#panel-proceed-').fadeIn(400);
                    return (!0);
                };
                self.click_proceed = function(ev) {
                    var _action = REPORT, _actionType = self.xReportNames_selected();
                    ACTIVE_REPORT_NAME = '';
                    if(self.xCustomReport() != void 0 && !self.xCustomReport()) {
                        _action = self.xWorstSwitch(), _actionType = 'Worst' + self.xWorstOptions_selected();
                        self.xReportNames_selected(_action == 'custom_DVR' ? 'Exceptions Count By DVR By Date' : 'Exceptions Count By Cashier By Date');
                        _proc_main(__sp_POSExceptionsGraphReports(void 0, _action, _actionType, self.xReportNames_selected(), _dateShort_1(self.date_from()), _dateShort_1(self.date_to()), '', self.xExceptions_selected()), _proc_comm_cb, REPORT, self.xReportNames_selected(), void 0, void 0, "click_proceed");
                        return !0;
                    }
                    _proc_main(__sp_POSExceptionsGraphReports(void 0, _action, _actionType, self.xReportNames_selected(), _dateShort_1(self.date_from()), _dateShort_1(self.date_to()), self.xDVRs_selected(), self.xExceptions_selected()), _proc_comm_cb, REPORT, self.xReportNames_selected(), void 0, void 0, "click_proceed");
                    return !0;
                }
                self.xCustomReport_click = function (e) {
                    self.xExceptions_selected.pushAllEx(self.xExceptions(), !0);
                    return $("#click-proceed-").addClass("-disabled-"), $("#click-proceed-").attr("disabled", "disabled"), self.enable_panel_custom(!1), self.enable_panel_custom(self.xDVRs().length > 0 && self.xExceptions().length > 0), !self.xCustomReport() && self.xExceptions_selected().length > 0 && ($("#click-proceed-").removeClass("-disabled-"), $("#click-proceed-").removeAttr("disabled")), void 0 != self.xExceptions_selected && self.xExceptions_selected().length > 0 && void 0 != self.xDVRs_selected && self.xDVRs_selected().length > 0 && ($("#click-proceed-").removeClass("-disabled-"), $("#click-proceed-").removeAttr("disabled")), 0 == self.xDVRs().length || 0 == self.xExceptions().length ? (console.log("No Records Found ( DVR and/or Exceptions )"), $.growlUI("No Records Found ( DVR and/or Exceptions )", "Please change the dates and try again", 300), !1) : self.xCustomReport() ? ($("#panel-custom-").fadeOut(300), $("#panel-proceed-").fadeIn(400), !0) : ($("#panel-custom-").fadeIn(400), $("#panel-proceed-").fadeOut(300), !0)
                };
                self._ev_xDates_selected = self.ev_doAny({
                    doAny: function() {
                        var date1 = self.date_from(), date2 = self.date_to();
                        self.xDVRs_selected([]);
                        self.xExceptions_selected([]);
                        self.enable_click_go(!1);
                        $('#worst-select-').addClass('-disabled-');
                        $('#panel-proceed-').addClass('-disabled-');
                        $('#panel-proceed-').attr('disabled', 'disabled');
                        $('#xDVRs-select').multiselect('disable');
                        $('#xExceptions-select').multiselect('disable');
                        $('#xDVRs-select').attr('disabled', 'disabled');
                        $('#xExceptions-select').attr('disabled', 'disabled');
                        $('.multiselect-selected-text').attr('disabled', 'disabled');
                        $('.btn-group').attr('disabled', 'disabled');
                        self.enable_panel_proceed(!1);
                        self.date_range(date_diff_indays(date1, date2));
                        if(self.date_range() < 0) {
                            setTimeout(
                                function() {
                                    console.log('Invalid the date range');
                                    $.growlUI('Invalid the date range', 'Please change the dates and try again', 300);
                                    $.unblockUI;
                                }, 200);
                            $('#click-proceed-').attr('disabled', 'disabled');
                            $('#click-proceed-').addClass('-disabled-');
                            self.enable_click_proceed(!1);
                            self.enable_panel_custom(!1);
                            return !0;
                        }
                        { date1 && date2 && self.enable_click_go(!0); }
                    }
                });
                self._ev_xEx_selected = self.ev_doAny({
                    doAny: function() {
                        var e = self.xDVRs_selected().length, d = self.xExceptions_selected().length;
                        return $("#click-proceed-").attr("disabled", "disabled"), $("#click-proceed-").addClass("-disabled-"), e > 0
                            && d > 0 ? ($("#click-proceed-").removeAttr("disabled"), $("#click-proceed-").removeClass("-disabled-"), !0) : d > 0
                            && !self.xCustomReport() ? ($("#click-proceed-").removeAttr("disabled"), $("#click-proceed-").removeClass("-disabled-"), !0) : void 0
                            ;
                    }
                });
                self._ev_after_go = self.ev_doAny({
                    doAny: function() {
                        var ex1 = self.xDVRs().length, ex2 = self.xExceptions().length;
                        $('#worst-select-').addClass('-disabled-');
                        $('#panel-proceed-').addClass('-disabled-');
                        $('#panel-proceed-').attr('disabled', 'disabled');
                        $('#xDVRs-select').multiselect('disable');
                        $('#xExceptions-select').multiselect('disable');
                        $('#xDVRs-select').attr('disabled', 'disabled');
                        $('#xExceptions-select').attr('disabled', 'disabled');
                        $('.multiselect-selected-text').attr('disabled', 'disabled');
                        $('.btn-group').attr('disabled', 'disabled');
                        self.enable_panel_proceed(!1), self.enable_panel_custom(!1);

                        ex1 > 0 && ex2 > 0 && ($("#worst-select-").removeClass("-disabled-"), $("#panel-proceed-").removeClass("-disabled-"), $("#panel-proceed-").removeAttr("disabled"), $("#worst-select-").removeClass("-disabled-")
                            , $("#xDVRs-select").multiselect("enable"), $("#xExceptions-select").multiselect("enable"), $("#xDVRs-select").removeAttr("disabled"), $("#xExceptions-select").removeAttr("disabled")
                            , $(".multiselect-selected-text").removeAttr("disabled"), $(".btn-group").removeAttr("disabled"), self.enable_panel_proceed(!0), self.enable_panel_custom(!0), !self.xCustomReport()
                            && self.xExceptions_selected().length > 0 && ($("#click-proceed-").removeClass("-disabled-"), $("#click-proceed-").removeAttr("disabled")), self.xDVRs_selected().length > 0
                            && self.xExceptions_selected().length > 0 && ($("#click-proceed-").removeClass("-disabled-"), $("#click-proceed-").removeAttr("disabled")));
                    }
                });
                self._ev_xDates_selected = self.ev_doAny({
                    doAny: function() {
                        var date1 = self.date_from(), date2 = self.date_to();
                        self.xDVRs_selected([]);
                        self.xExceptions_selected([]);
                        self.enable_click_go(!1);
                        $('#worst-select-').addClass('-disabled-');
                        $('#panel-proceed-').addClass('-disabled-');
                        $('#panel-proceed-').attr('disabled', 'disabled');
                        $('#xDVRs-select').multiselect('disable');
                        $('#xExceptions-select').multiselect('disable');
                        $('#xDVRs-select').attr('disabled', 'disabled');
                        $('#xExceptions-select').attr('disabled', 'disabled');
                        $('.multiselect-selected-text').attr('disabled', 'disabled');
                        $('.btn-group').attr('disabled', 'disabled');
                        self.enable_panel_proceed(!1);
                        self.date_range(date_diff_indays(date1, date2));
                        if(self.date_range() < 0) {
                            setTimeout(
                                function() {
                                    console.log('Invalid the date range');
                                    $.growlUI('Invalid the date range', 'Please change the dates and try again', 400);
                                }, 200);
                            $('#click-proceed-').attr('disabled', 'disabled');
                            $('#click-proceed-').addClass('-disabled-');
                            self.enable_click_proceed(!1);
                            self.enable_panel_custom(!1);
                            return (!0);
                        }
                        if(date1 && date2) { self.enable_click_go(!0) }
                    }
                });
                self._ev_xEx_selected = self.ev_doAny({
                    doAny: function() {
                        var e = self.xDVRs_selected().length, d = self.xExceptions_selected().length;
                        return $("#click-proceed-").attr("disabled", "disabled"), $("#click-proceed-").addClass("-disabled-"), e > 0
                            && d > 0 ? ($("#click-proceed-").removeAttr("disabled"), $("#click-proceed-").removeClass("-disabled-"), !0) : d > 0
                                && !self.xCustomReport() ? ($("#click-proceed-").removeAttr("disabled"), $("#click-proceed-").removeClass("-disabled-"), !0) : void 0
                            ;
                    }
                });
                !0 && setInterval(function() { self.__time((new Date())._today() + ' - ' + (new Date()).toLocaleTimeString()); }, 1000);
            } catch(e) { console.log(e.message); return !0; }
            $('#xDVRs-select').change(function() { if($("#panel-proceed- > span:nth-child(1) > div > ul > li.active > a > label").text().includes(deselectAll)) return $("#xDVRs-select").multiselect("deselectAll", !1), !0 });
            $('#xDVRs-select').multiselect({
                maxHeight: 200,
                buttonWidth: 100,
                onChange: function(ev) {if($('#panel-proceed- > span:nth-child(1) > div > ul > li.active > a > label').text().includes(deselectAll)) return $("#xDVRs-select").multiselect("deselectAll", !1), !0 },
                onDropdownHidden: function(ev) { }
            });
            b_flag = !1;
            core_ui(function(o, i) {
                try {
                    if(o.chart.NoShow) {
                        if(!o.allOnce) {
                            if(1 !== i) return;
                            o.allOnce = !0
                        }
                        o.options.enabled = !0, t.helpers.each(o.pluginTooltips, function(o) {
                            o.initialize(), o._options.bodyFontSize = .02 * o._chart.height, o._options.bodyFontColor = "white", o._options.hoverBackgroundColor = "rgba(225, 0, 55, 0.7)", o._options.border = "1px solid #125215", o._options = 4, o._options = 6, o._options.backgroundColor = "#97A5B3", o.update(), o.pivot(), o.transition(i)[0]
                        }), o.options.enabled = !1
                    }
                } catch (e) { console.log(e.message); return !0; }
            });
        }
        $.blockUI();
        vm_main = new _vm_main('G');
        ko.applyBindings(vm_main);
        _lnum = 1;
        function _report_title(v) { return ('' + _dateShort(vm_main.date_from()) + ' - ' + _dateShort(vm_main.date_to()) + ' ~ ' + v + ' ~ ');}
        function _decodeHtml(e) { return e = e.replace(/&/g, "&").replace(/</g, "<").replace(/>/g, ">").replace(/'/g, "'").replace(/"/g, '"').replace(/ /g, " ").replace(/©/g, "@").replace(/®/g, "?") }
        function _proc_comm_cb_url(result, _action, _actionType, _sub_action, _any) {
            document.getElementById('modal-').style.display = 'block';
            vm_main.urlLinks.pushAllEx(result._datasets, !0);
        }
        function _proc_comm_cb(result, _action, _actionType, _sub_action, _any, _xtra) {
            try {
                _lnum = 21;
                if(!result._datasets.length) {
                    setTimeout(
                        function() {
                            console.log('No Records Found ( DVR and/or Exceptions )');
                            $.growlUI('No Records Found ( DVR and/or Exceptions )', 'Please change the dates and try again', 300);
                            $.unblockUI;
                        }, 200);
                    return !0;
                }
                if("click_proceed" == _xtra && vm_main.weightFactor()) {
                    let t = "",
                        e = 0;
                    for(let a = 0; a < WEIGHT_FACTOR_ARR.length; a++) try {
                        if(t = WEIGHT_FACTOR_ARR[a].split("=")[0].trim(), (e = parseInt(WEIGHT_FACTOR_ARR[a].split("=")[1].trim())) > 0 && 100 != e)
                            for(let a = 0; a < result._datasets.length; a++) result._datasets[a].Title == t && (result._datasets[a].Total = result._datasets[a].Total * e / 100)
                    } catch (e) { console.log(e.message); return !0; }
                }
                _lnum = 2;
                if(_action == 'code') {
                    if(_actionType == 'DVR') {
                        if(!result._datasets.length) { return !0; }
                        vm_main.xDVRs([]);
                        vm_main.xDVRs_selected([]);
                        var _arr = result._datasets.map(function(a) { return (a.DVR) });
                        vm_main.xDVRs.pushAllEx(DVR_exra, !0);
                        vm_main.xDVRs.pushAllEx(_arr, !1);
                    }
                    if(_actionType == 'exceptions') {
                        if(!result._datasets.length) { return !0}
                        vm_main.xExceptions([]);
                        vm_main.xExceptions_selected([]);
                        var _arr = result._datasets.map(function(a) { return (a._Name) });
                        vm_main.xExceptions.pushAllEx(_arr, !0);
                        if(!vm_main.xCustomReport()) {
                            vm_main.xExceptions_selected.pushAllEx(_arr, !0);
                            $('#xExceptions-select').each(function() { this.selected = !0 });
                            $("#xExceptions-select").multiselect('selectAll', !1);
                        }
                    }
                    $('#click-proceed-').removeClass('-disabled-');
                    $('#click-proceed-').removeAttr('disabled');
                }
                if(_action == REPORT) {
                    _lnum = 3;
                    var rep_title_text = "" == ACTIVE_REPORT_NAME ? _report_title(vm_main.xReportNames_selected()) : ACTIVE_REPORT_NAME, chart_type = "line", xname = "Date", yname = ["Total", "Average"], YnameAsValue = "Title";
                    "Exceptions Count By DVR By Hour" == _actionType && null == _sub_action && (xname = "Time_Range", yname = ["Total"], YnameAsValue = "Title", b_flag = !0, show_chart(_actionType, chart_type, result._datasets, result._datasets, xname, yname, YnameAsValue, rep_title_text)), "Exceptions Count By Date" == _actionType && (_lnum = 4, "Exceptions By DVR" == _sub_action && (chart_type = "line", xname = ["Title"], yname = ["Total"], YnameAsValue = "Title", rep_title_text = _any, b_flag = !0, show_chart(_sub_action, chart_type, result._datasets, result._datasets, xname, yname, YnameAsValue, rep_title_text)), "Exceptions By Hour" == _sub_action && (_lnum = 5, chart_type = "line", xname = "Time_Range", yname = ["Total"], YnameAsValue = "ExName", rep_title_text = _any, b_flag = !0, show_chart(_sub_action, chart_type, result._datasets, result._datasets, xname, yname, YnameAsValue, rep_title_text)), null == _sub_action && (xname = "Date", yname = ["Total"], YnameAsValue = "ExName", _lnum = 6, b_flag = !0, show_chart(_actionType, chart_type, result._datasets, result._datasets, xname, yname, YnameAsValue, rep_title_text))), "Exceptions Count By DVR By Date" == _actionType && (_lnum = 7, "Cashiers By Hour" == _sub_action && (xname = "Time_Range", yname = ["Total"], YnameAsValue = "CashierID", rep_title_text = _any, b_flag = !0, show_chart(_sub_action, chart_type, result._datasets, result._datasets, xname, yname, YnameAsValue, rep_title_text)), "Exceptions By Hour" == _sub_action && (xname = "Time_Range", yname = ["Total"], YnameAsValue = "ExName", rep_title_text = _any, _lnum = 8, b_flag = !0, show_chart(_sub_action, chart_type, result._datasets, result._datasets, xname, yname, YnameAsValue, rep_title_text)), null == _sub_action && (_lnum = 9, b_flag = !0, show_chart(_actionType, chart_type, result._datasets, result._datasets, xname, yname, YnameAsValue, rep_title_text))), "Exceptions Count By Cashier By Date" == _actionType && (xname = "Date", yname = ["Total"], YnameAsValue = "CashierID", _lnum = 10, "Exceptions By Hour" == _sub_action && (xname = "Time_Range", yname = ["Total"], YnameAsValue = "ExName", rep_title_text = _any, b_flag = !0, show_chart(_sub_action, chart_type, result._datasets, result._datasets, xname, yname, YnameAsValue, rep_title_text)), _lnum = 11, null == _sub_action && (b_flag = !0, show_chart(vm_main.xReportNames_selected(), chart_type, result._datasets, result._datasets, xname, yname, YnameAsValue, rep_title_text))), "Exceptions Count Daily Average By DVR" == _actionType && (b_flag = !0, chart_type = "line", xname = "Title", yname = ["Average"], YnameAsValue = "", _lnum = 12, show_chart(vm_main.xReportNames_selected(), chart_type, result._datasets, result._datasets, xname, yname, YnameAsValue, rep_title_text), setTimeout(function() { b_flag = !1 }, 200)),
                    "Exceptions Count By DVR" == _actionType && (chart_type = "line", xname = "Title", yname = ["Total"], YnameAsValue = "", _lnum = 13, "Cashiers By Date" == _sub_action && (chart_type = "line", xname = "Date", yname = ["Total"], YnameAsValue = "CashierID", rep_title_text = _any, b_flag = !0, show_chart(_sub_action, chart_type, result._datasets, result._datasets, xname, yname, YnameAsValue, rep_title_text)), "Exceptions By Hour" == _sub_action && (chart_type = "line", xname = "Time_Range", yname = ["Total"], YnameAsValue = "ExName", rep_title_text = _any, b_flag = !0, show_chart(_sub_action, chart_type, result._datasets, result._datasets, xname, yname, YnameAsValue, rep_title_text)), null == _sub_action && (b_flag = !0, show_chart(vm_main.xReportNames_selected(), chart_type, result._datasets, result._datasets, xname, yname, YnameAsValue, rep_title_text))), "Exceptions Count By Cashier" == _actionType && (chart_type = "line", xname = "CashierID", yname = ["Total"], YnameAsValue = "", _lnum = 14, "Cashiers By Date" == _sub_action && (chart_type = "line", xname = "Date", yname = ["Total"], YnameAsValue = "CashierID", rep_title_text = _any, b_flag = !0, show_chart(_sub_action, chart_type, result._datasets, result._datasets, xname, yname, YnameAsValue, rep_title_text)), "Exceptions By Hour" == _sub_action && (chart_type = "line", xname = "Time_Range", yname = ["Total"], YnameAsValue = "ExName", rep_title_text = _any, b_flag = !0, _lnum = 15, show_chart(_sub_action, chart_type, result._datasets, result._datasets, xname, yname, YnameAsValue, rep_title_text)), null == _sub_action && (b_flag = !0, _lnum = 16, show_chart(vm_main.xReportNames_selected(), chart_type, result._datasets, result._datasets, xname, yname, YnameAsValue, rep_title_text)))
                }
                { _actionType == 'url' && ((document.getElementById('modal-').style.display = 'block') && vm_main.urlLinks.pushAllEx(result._datasets, !0)), setTimeout(function() { b_flag = !1 }, 200) }
            } catch(e) { $.unblockUI; console.log(e.name + '\n' + _tag + ' :< _proc_comm_cb = function(result > _lnum : ' + _lnum + '\n' + e.message) }
            setTimeout(function() { b_flag = !1 }, 200);
        }; 
        function _cb_chart_click(_rep_id, _label, _value, _labelLegent, _title_text) {
            {   if("Exceptions By Hour" == _title_text.substring(_title_text.lastIndexOf(":") + 1).trim()) {
                var t, e = _title_text.split(":")[1].trim(), i = _title_text.match(new RegExp("~(.*)~"))[1].trim();
                return "Exceptions Count By DVR By Date" != i && "Exceptions Count By DVR" != i && "Exceptions Count By Cashier" != i && "Exceptions Count By Cashier By Date" != i || ("Exceptions Count By Cashier" != i && "Exceptions Count By DVR" != i || (e = _title_text.split(":")[4].trim()), "Exceptions Count By DVR By Date" == i && (t = _title_text.split(":")[4].trim()), "Exceptions Count By Cashier By Date" == i && (t = _title_text.split(":")[2].trim()), "Exceptions Count By DVR" == i && (t = _title_text.split(":")[3].trim()), "Exceptions Count By Cashier" == i && (t = _title_text.split(":")[1].trim()), _proc_main(__sp_URL("dbo.__sp_URL", "get", "url", "none", i, "Exceptions_By_Hour", _title_text, t, e, _label.split("-")[0].trim(), _label.split("-")[1].trim(), _labelLegent.substr(0, _labelLegent.indexOf("(")).trim()), _proc_comm_cb_url, "get", "url", "Exceptions_By_Hour", _label)), !0
                }
            }
            _lnum = 4848;
            if($('#' + _rep_id.replace('chart-', 'container-')).hasClass('-container-small-')) {  return !0 }; 
            var rep_parent = _title_text.match(new RegExp('~' + '(.*)' + '~'))[1].trim(), _sub = '', _title = '', _ttitle = '', _lbl_sub = '', _rep_4sp = rep_parent, _date = new Date();
            _lnum = 20;
            if(_rep_id == 'chart-Exceptions_Count_By_DVR_By_Date') {
                _sub = 'Cashiers By Hour', _ttitle = _labelLegent.substr(0, _labelLegent.indexOf('(')).trim();
                _title = _title_text + ' : ' + _label + ' : ' + _ttitle + ' : ' + _sub;
                { if(null != vm_main.xCustomReport() && !vm_main.xCustomReport()) return _proc_main(__sp_POSExceptionsGraphReports(void 0, REPORT, _rep_4sp, _sub, _label, _label, _ttitle, ""), _proc_comm_cb, REPORT, _rep_4sp, _sub, _title), !0 }
                { _proc_main(__sp_POSExceptionsGraphReports(undefined, REPORT, _rep_4sp, _sub, _label, _label, _ttitle, vm_main.xExceptions_selected()), _proc_comm_cb, REPORT, _rep_4sp, _sub, _title); }
            }
            _lnum = 21;
            if(_rep_id == 'chart-Cashiers_By_Hour') {
                _sub = 'Exceptions By Hour', _date = _title_text.split(':')[1].trim(), _ttitle = _title_text.split(':')[2].trim(), _lbl_sub = _labelLegent.substr(0, _labelLegent.indexOf('(')).trim(), _rep_4sp = rep_parent;
                _title = _title_text + ' : ' + _lbl_sub + ' : ' + _sub;
                _proc_main(__sp_POSExceptionsGraphReports(undefined, REPORT, _rep_4sp, _sub, _date, _date, _ttitle, vm_main.xExceptions_selected(), _lbl_sub), _proc_comm_cb, REPORT, _rep_4sp, _sub, _title);
            }
            if(_rep_id == 'chart-Exceptions_By_DVR') {
                _sub = 'Exceptions By Hour', _date = _title_text.split(':')[1].trim(), _ttitle = _title_text.split(':')[2].trim(), _lbl_sub = _labelLegent.substr(0, _labelLegent.indexOf('(')).trim(), _rep_4sp = rep_parent;
                _title = _title_text + ' : ' + _lbl_sub + ' : ' + _sub;
                _proc_main(__sp_POSExceptionsGraphReports(undefined, REPORT, _rep_4sp, _sub, _date, _date, _label, _ttitle, undefined), _proc_comm_cb, REPORT, _rep_4sp, _sub, _title);
            }
            {
            "chart-Cashiers_By_Date" == _rep_id && (_lnum = 22, "Exceptions Count By Cashier" == rep_parent && (_sub = "Exceptions By Hour", _date = _label, _ttitle = _title_text.split(":")[1].trim(), _lbl_sub = _labelLegent.substr(0, _labelLegent.indexOf("(")).trim(), _rep_4sp = rep_parent, _title = _title_text + " : " + _lbl_sub + " : " + _label + " : " + _sub, _proc_main(__sp_POSExceptionsGraphReports(void 0, REPORT, _rep_4sp, _sub, _date, _date, _lbl_sub, vm_main.xExceptions_selected(), _lbl_sub), _proc_comm_cb, REPORT, _rep_4sp, _sub, _title)), "Exceptions Count By DVR" == rep_parent && (_sub = "Exceptions By Hour", _date = _label, _ttitle = _title_text.split(":")[1].trim(), _lbl_sub = _labelLegent.substr(0, 1).trim(), _rep_4sp = rep_parent, _ttitle = _title_text + " : " + _lbl_sub + " : " + _label + " : " + _sub, _proc_main(__sp_POSExceptionsGraphReports(void 0, REPORT, _rep_4sp, _sub, _date, _date, _ttitle, vm_main.xExceptions_selected(), _lbl_sub), _proc_comm_cb, REPORT, _rep_4sp, _sub, _title)), "Exceptions Count By Cashier By Date" == rep_parent && (_sub = "Exceptions By Hour", _date = _label, _ttitle = _title_text.split(":")[1].trim(), _lbl_sub = _labelLegent.substr(0, _labelLegent.indexOf("(")).trim(), _rep_4sp = rep_parent, _title = _title_text + " : " + _lbl_sub + " : " + _label + " : " + _sub, _proc_main(__sp_POSExceptionsGraphReports(void 0, REPORT, _rep_4sp, _sub, _date, _date, vm_main.xDVRs_selected(), vm_main.xExceptions_selected(), _lbl_sub), _proc_comm_cb, REPORT, _rep_4sp, _sub, _ttitle)));
            }
            if(_rep_id == 'chart-Exceptions_Count_By_Date') {
                _lnum = 23;
                _sub = 'Exceptions By DVR', _rep_4sp = rep_parent, _lbl_sub = _labelLegent.substr(0, _labelLegent.indexOf('(')).trim();
                _title = _title_text + ' : ' + _label + ' : ' + _lbl_sub + ' : ' + _sub;
                _proc_main(__sp_POSExceptionsGraphReports(undefined, REPORT, _rep_4sp, _sub, _label, _label, vm_main.xDVRs_selected(), _lbl_sub), _proc_comm_cb, REPORT, _rep_4sp, _sub, _title);
            }
            if(_rep_id == 'chart-Exceptions_Count_By_DVR') {
                _sub = 'Cashier By Date', _rep_4sp = rep_parent;
                _title = _title_text + ' : ' + _label + ' : ' + _sub;
                _proc_main(__sp_POSExceptionsGraphReports(undefined, REPORT, _rep_4sp, _sub, vm_main.date_from(), vm_main.date_to(), _label, vm_main.xExceptions_selected()), _proc_comm_cb, REPORT, _rep_4sp, _sub, _title);
            }
            { "chart-Exceptions_Count_Daily_Average_By_DVR" == _rep_id && (_sub = "Cashiers_By_Hour"), "chart-Exceptions_Count_By_DVR_By_Hour" == _rep_id && (_sub = "Cashiers_By_Hour"); }
            if(_rep_id == 'chart-Exceptions_Count_By_Cashier') {
                _sub = 'Cashier By Date', _rep_4sp = rep_parent;
                _title = _title_text + ' : ' + _label + ' : ' + _sub;
                _proc_main(__sp_POSExceptionsGraphReports(undefined, REPORT, _rep_4sp, _sub, vm_main.date_from(), vm_main.date_to(), _title_text, vm_main.xExceptions_selected(), _label), _proc_comm_cb, REPORT, _rep_4sp, _sub, _title);
            }
            if(_rep_id == 'chart-Exceptions_Count_By_Cashier_By_Date') {
                _sub = 'Exceptions By Hour', _date = _label, _rep_4sp = rep_parent, _ttitle = _labelLegent.substr(0, _labelLegent.indexOf('(')).trim(), _lbl_sub = _labelLegent.substr(0, _labelLegent.indexOf('(')).trim();
                _title = _title_text + ' : ' + _label + ' : ' + _ttitle + ' : ' + _sub;
                if(void 0 != vm_main.xCustomReport() && !vm_main.xCustomReport()) {
                    _proc_main(__sp_POSExceptionsGraphReports(undefined, REPORT, _rep_4sp, _sub, _date, _date, '', vm_main.xExceptions_selected(), _lbl_sub), _proc_comm_cb, REPORT, _rep_4sp, _sub, _title);
                    return !0;
                }
                _proc_main(__sp_POSExceptionsGraphReports(void 0, REPORT, _rep_4sp, _sub, _date, _date, vm_main.xDVRs_selected(), vm_main.xExceptions_selected(), _lbl_sub), _proc_comm_cb, REPORT, _rep_4sp, _sub, _title);
            }
        };
        function fix_n(n) {
            n = n.replace("container-", ""), $("div[id^='container-']").removeClass("-container-big-"), $("div[id^='container-']").addClass("-container-small-"), ACTIVE_REPORT_NAME = n, $("#container-" + xstring(n)).removeClass(), $("#container-" + xstring(n)).addClass("-container-big-")
        }
        function show_chart(_report_name, _type, _data_chart, _data_table, _Xname, _Yname, _YnameAsValue, _chart_title) {
            try { _type = (_data_chart.length < 16) ? 'bar' : 'line'; } catch (e) { console.log(e.message); console.log(_data_chart); return !0 }
            try {
                _lnum = 48, vm_main.__current_title(_chart_title);
                fix_n(_report_name), $('#container-' + xstring(_report_name)).unbind('click');
                var _rep_config = {
                    report_name: xstring(_report_name),
                    point_fnc: function(i, t, _, o, n) {
                        if("Exceptions By Hour" == n.substring(n.lastIndexOf(":") + 1).trim()) {
                            var c, e = n.split(":")[1].trim(), s = n.match(new RegExp("~(.*)~"))[1].trim();
                            return "Exceptions Count By DVR By Date" != s && "Exceptions Count By DVR" != s && "Exceptions Count By Cashier" != s && "Exceptions Count By Cashier By Date" != s || ("Exceptions Count By Cashier" != s && "Exceptions Count By DVR" != s || (e = n.split(":")[4].trim()), "Exceptions Count By DVR By Date" == s && (c = n.split(":")[4].trim()), "Exceptions Count By Cashier By Date" == s && (c = n.split(":")[2].trim()), "Exceptions Count By DVR" == s && (c = n.split(":")[3].trim()), "Exceptions Count By Cashier" == s && (c = n.split(":")[1].trim()), _proc_main(__sp_URL("dbo.__sp_URL", "get", "url", "none", s, "Exceptions By Hour", n, c, e, t.split("-")[0].trim(), t.split("-")[1].trim(), o.substr(0, o.indexOf("(")).trim()), _proc_comm_cb_url, "get", "url", "Exceptions By Hour", t), !0)
                        }
                        if(!$("#" + i.replace("chart-", "container-")).hasClass("-container-small-")) {
                            var a = n.match(new RegExp("~(.*)~"))[1].trim(), m = "", r = "", z = "ftp:first@ftp:second", p = "", u = "", R = a, x = new Date;
                            if("chart-Exceptions_Count_By_DVR_By_Date" == i) {
                                if(m = "Cashiers By Hour", R = a, r = n + " : " + t + " : " + (p = o.substr(0, o.indexOf("(")).trim()) + " : " + m, null != vm_main.xCustomReport() && !vm_main.xCustomReport()) return void _proc_main(__sp_POSExceptionsGraphReports(void 0, REPORT, R, m, t, t, p, ""), _proc_comm_cb, REPORT, R, m, r);
                                _proc_main(__sp_POSExceptionsGraphReports(void 0, REPORT, R, m, t, t, p, vm_main.xExceptions_selected()), _proc_comm_cb, REPORT, R, m, r)
                                }
                                if("chart-Cashiers_By_Hour" == i && (m = "Exceptions By Hour", x = n.split(":")[1].trim(), p = n.split(":")[2].trim(), R = a, z = z.split("@")[0], r = n + " : " + (u = o.substr(0, o.indexOf("(")).trim()) + " : " + m, _proc_main(__sp_POSExceptionsGraphReports(void 0, REPORT, R, m, x, x, p, vm_main.xExceptions_selected(), u), _proc_comm_cb, REPORT, R, m, r)), "chart-Exceptions_By_DVR" == i && (m = "Exceptions By Hour", x = n.split(":")[1].trim(), p = n.split(":")[2].trim(), R = a, r = n + " : " + (u = o.substr(0, o.indexOf("(")).trim()) + " : " + m, _proc_main(__sp_POSExceptionsGraphReports(void 0, REPORT, R, m, x, x, t, p, void 0), _proc_comm_cb, REPORT, R, m, r)), "chart-Cashiers_By_Date" == i && ("Exceptions Count By Cashier" == a && (m = "Exceptions By Hour", x = t, p = n.split(":")[1].trim(), R = a, r = n + " : " + (u = o.substr(0, o.indexOf("(")).trim()) + " : " + t + " : " + m, _proc_main(__sp_POSExceptionsGraphReports(void 0, REPORT, R, m, x, x, u, vm_main.xExceptions_selected(), u), _proc_comm_cb, REPORT, R, m, r)), "Exceptions Count By DVR" == a && (m = "Exceptions By Hour", x = t, p = n.split(":")[1].trim(), R = a, r = n + " : " + (u = o.substr(0, o.indexOf("(")).trim()) + " : " + t + " : " + m, _proc_main(__sp_POSExceptionsGraphReports(void 0, REPORT, R, m, x, x, p, vm_main.xExceptions_selected(), u), _proc_comm_cb, REPORT, R, m, r)), "Exceptions Count By Cashier By Date" == a && (m = "Exceptions By Hour", x = t, p = n.split(":")[1].trim(), R = a, r = n + " : " + (u = o.substr(0, o.indexOf("(")).trim()) + " : " + t + " : " + m, _proc_main(__sp_POSExceptionsGraphReports(void 0, REPORT, R, m, x, x, vm_main.xDVRs_selected(), vm_main.xExceptions_selected(), u), _proc_comm_cb, REPORT, R, m, r))), "chart-Exceptions_Count_By_Date" == i && (m = "Exceptions By DVR", R = a, r = n + " : " + t + " : " + (u = o.substr(0, o.indexOf("(")).trim()) + " : " + m, _proc_main(__sp_POSExceptionsGraphReports(void 0, REPORT, R, m, t, t, vm_main.xDVRs_selected(), u), _proc_comm_cb, REPORT, R, m, r)), "chart-Exceptions_Count_By_DVR" == i && (R = a, r = n + " : " + t + " : " + (m = "Cashiers By Date"), _proc_main(__sp_POSExceptionsGraphReports(void 0, REPORT, R, m, vm_main.date_from(), vm_main.date_to(), t, vm_main.xExceptions_selected()), _proc_comm_cb, REPORT, R, m, r)), "chart-Exceptions_Count_By_DVR_By_Hour" == i && (m = "Cashiers By Hour"), "chart-Exceptions_Count_By_Cashier" == i && (R = a, r = n + " : " + t + " : " + (m = "Cashiers By Date"), _proc_main(__sp_POSExceptionsGraphReports(void 0, REPORT, R, m, vm_main.date_from(), vm_main.date_to(), n, vm_main.xExceptions_selected(), t), _proc_comm_cb, REPORT, R, m, r)), "chart-Exceptions_Count_By_Cashier_By_Date" == i) {
                                if(m = "Exceptions By Hour", x = t, R = a, p = o.substr(0, o.indexOf("(")).trim(), u = o.substr(0, o.indexOf("(")).trim(), r = n + " : " + t + " : " + p + " : " + m, null != vm_main.xCustomReport() && !vm_main.xCustomReport()) return void _proc_main(__sp_POSExceptionsGraphReports(void 0, REPORT, R, m, x, x, "", vm_main.xExceptions_selected(), u), _proc_comm_cb, REPORT, R, m, r);
                                  _proc_main(__sp_POSExceptionsGraphReports(void 0, REPORT, R, m, x, x, vm_main.xDVRs_selected(), vm_main.xExceptions_selected(), u), _proc_comm_cb, REPORT, R, m, r)
                            }
                        }
                    },
                    cb_chart_click: _cb_chart_click,
                    image_support: cb_menu,
                    image_fnc: function(t, r, n, e) {
                        n || (n = "");
                        var f = function(t, n, o) {
                            if(t instanceof Array)
                                for(var a = 0, i = t.length; a < i; a++) e += o + f(t[a], n, o + "\t") + "\n";
                            else if("object" == typeof t) {
                                for(var c in e += o + "<" + n, t) "@" == c.fdU(0) ? e += " " + c.substr(1) + '="' + t[c].toString() + '"' : r = !0;
                                if(e += r ? ">" : "/>", r) {
                                    for(var c in t) "#text" == c ? e += t[c] : "#cD" == c ? e += "<![cD[" + t[c] + "]]>" : "@" != c.fdU(0) && (e += f(t[c], c, o + "\t"));
                                    e += ("\n" == e.fdU(e.length - 1) ? o : "") + "</" + n + ">"
                                }
                            } else e += o + "<" + n + ">" + t.toString() + "</" + n + ">";
                            return e
                        };
                        e = t;
                        for(var a in o) e += f(o[a], a, "");
                        return n ? e.replace(/\t/g, n) : e.replace(/\t|\n/g, "")
                    },
                    chart_title: _chart_title,
                    data_chart: _data_chart,
                    data_table: _data_table,
                    Xname: _Xname,
                    Yname: _Yname,
                    YnameAsValue: _YnameAsValue,
                    alltips: !0,
                    type: _type
                };
                loadReport(_rep_config);
                setTimeout(function() {
                    $('#container-' + xstring(_report_name)).bind('click', function(ev) {
                        $('#report-container-normal-').append($(this)[0])
                        fix_n($(this)[0].id);
                        return !0
                    });
                }, 200);
            } catch(e) {
                $.unblockUI;
                console.log(e.name + '\n' + _tag + ' :< function show_chart( > _lnum : ' + _lnum + '\n' + e.message);
                return !0
            };
        };
        $("div[id^='container-']").removeClass();
        $("div[id^='container-']").addClass('-container-big-');
        $("div[id^='container-']").hide();
        $(window).resize(function(){window.resizeTo(1024, 800)});
    } catch(e) {
        $.unblockUI;
        console.log(e.name + '\n' + _tag + ' : _lnum : ' + _lnum + '\n' + e.message);
        return !0
    }
    $("#dialog-confirm-").dialog({
        autoOpen: !1, modal: !0, resizable: !1, position: [300, 100], width: 460, height: 140, show:{effect: "fade", speed: 200}
        , buttons: [
            { text: "YES", width: "120", title: "Choose YES to Continue", click: function(){vm_main.click_go("YES"), $(this).dialog("close")}}
            , {text: "NO", width: "120", title: "NO to shorten the date range", click: function(){vm_main.click_go("NO"), $(this).dialog("close")}}
        ]
    });
    setTimeout(
        function() {
            $('#head-').show();
            //  $("#body-").fadeIn("300");
            vm_main.xCustomReport(!1);
            $('#panel-custom-').fadeIn(400);
            $('#panel-proceed-').fadeOut(300);
            document.getElementById('modal-images-').style.display = 'none';
            document.getElementById('modal-').style.display = 'none';
            $.unblockUI();
    }, 600);
    return (this);
});

//  ----------------------------------------------------------------------------------------------------------------------

//  $('#report-container-normal-').resizable();
//  $('[id^=container-Exceptions]').each(function() {
//      $(this).resizable();
//  });

/*

            //  $("#body-").fadeIn("300")
            //  start();
            // (vm_main.__location(""), document.getElementById("id01").style.display = "none", $("#body-").fadeIn("300"), vm_main.__location(i.split("@")[0]), i.split("@")[1] && (WEIGHT_FACTOR_ARR = i.split("@")[1].split(",")), !0)


//  ----------------------------------------------------------------------------------------------------------------------
$('#xDVRs-select').change(function() {
    if($('#panel-proceed- > span:nth-child(1) > div > ul > li.active > a > label').text().includes(deselectAll)) {
        $('#xDVRs-select').multiselect('deselectAll', !1);
        return !0;
    }
    //  gm48  if(self.xDVRs_selected() == worst5 || self.xDVRs_selected() == worst10) {
    //  gm48      $('#xDVRs-select').multiselect('deselect', [self.xDVRs_selected()]);
    //  gm48  }
    if(self.xDVRs_selected().length > 2) {
        //  $.growlUI('Only 10 (ten) items selected is allowed', 'The last selected item is unselected', 400);
        //  var des = self.xDVRs_selected().pop();
        //  $('.-max-selected-').multiselect('deselect', [des]);
        //  $('#xDVRs-select >.-max-selected-').removeClass('open');
    }
});

$('#xDVRs-select').multiselect({
    maxHeight: 200,
    buttonWidth: 100,
    onChange: function(ev) {
        if($('#panel-proceed- > span:nth-child(1) > div > ul > li.active > a > label').text().includes(deselectAll)) {
            $('#xDVRs-select').multiselect('deselectAll', !1);
            return !0;
        }
        if(self.xDVRs_selected().length > 2) {
            //  $.growlUI('Only 10 (ten) items selected is allowed', 'The last selected item is unselected', 400);
            //  var des = self.xDVRs_selected().pop();
            //  $('.-max-selected-').multiselect('deselect', [des]);
            //  $('#xDVRs-select >.-max-selected-').removeClass('open');
        }
    },
    onDropdownHidden: function(ev) { }
});
*/