﻿//  "use strict";
define(function () {
    try {
        this.xstring = function (t) {
            return t.replace("(%)", "percent").replace(/[^a-z0-9\s]/gi, "_").replace(/[_\s]/g, "_").trim()
        }, this.xOptValues = function () {
            return ["02", "04", "07", "10", "15", "20"]
        }, this.xRepNames = function () {
            return ["Exceptions Count By DVR By Date", "Exceptions Count By DVR", "Exceptions Count By Cashier", "Exceptions Count By Cashier By Date", "Exceptions Count Daily Average By DVR", "Exceptions Count By Date", "Exceptions Count By DVR By Hour"]
        }, this.xImages = function () {
            return ["../ExceptionImages/2020/7/19/Non-Scanned/2020_04_19T0138557340000_3.jpg"
                , "../ExceptionImages/2020/7/19/Non-Scanned/2020_04_19T0140053250000_3.jpg"
                , "../ExceptionImages/2020/7/19/Non-Scanned/2020_04_19T1300074760000_1.jpg"
                , "../ExceptionImages/2020/7/19/Void/2020_04_19T0052130480000_1.jpg"
                , "../ExceptionImages/2020/7/19/Void/2020_04_19T0052130480000_1.jpg"
                , "../ExceptionImages/2020/7/19/Void/2020_04_19T0052130480000_1.jpg"
                , "../ExceptionImages/2020/7/19/Void/2020_04_19T0125087070000_3.jpg"
                , "../ExceptionImages/2020/7/19/Void/2020_04_19T0219304080000_3.jpg"]
        }
    } catch (t) {
        console.log(t.name + "\nobjects.meta-static : _lnum : 0\n" + t.message)
    }
    return this
});