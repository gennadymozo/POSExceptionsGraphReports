﻿//      "use strict";
require(["jquery", "knockout", "chart", "chart-ext"], function(t, n, o) {
    var e, a = "chart-report.chart_core",
        r = this, $$$DEBUG = !1
        i = o.Chart;
    try {
        function c(t, n, o) {
            return o.indexOf(t) === n
        }
        r.chart_config = function(t, n) {
            return n || (n = "just a report text (title:text)"), null == t && (t = !0), {
                title: {
                    display: !0,
                    text: n
                },
                tooltips: {
                    displayColors: !1,
                    callbacks: {
                        label: function(t, n) {
                            const o = n.datasets[t.datasetIndex].data[t.index];
                            try {
                                var e = o.toFixed(1)
                            } catch (t) {
                                e = o
                            }
                            return o > 999 ? (o / 1e3).toFixed(1) + "k" : e
                        },
                        title: function(t, n) {}
                    }
                },
                showAllTooltips: t,
                plugins: {
                    alwaysTooltips: t
                },
                legend: {
                    display: !0,
                    position: "right",
                    alignment: "start",
                    labels: {
                        boxWidth: 4,
                        fontSize: 12,
                        fontColor: "black"
                    },
                    events: ["mousemove"],
                    onHover: function(t, n) {
                        t.target.style.cursor = "pointer"
                    }
                },
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: !0,
                            callback: function(t, n, o) {
                                return t > 999 ? (t / 1e3).toFixed(1) + "k" : t.toFixed(1)
                            },
                            fontColor: "DarkRed"
                        },
                        scaleLabel: {
                            display: !0,
                            labelString: "1k = 1000",
                            fontColor: "DarkRed"
                        }
                    }],
                    xAxes: [{
                        ticks: {
                            minRotation: 90,
                            fontColor: "DarkBlue"
                        }
                    }]
                }
            }
        }, r.rep_defaults = {
            report_name: "Exceptions_Count_By_DVR_By_Date",
            data_chart: {},
            data_table: {},
            Xname: "",
            Yname: [],
            YnameAsValue: void 0,
            alltips: !0,
            type: "line",
            point_fnc: function(t, n, o, e, a) {},
            table_array2push: []
        }, r.cleanReports = function() {}, r.bind_click_canvas_chart = function(t, n, o) {
            t instanceof HTMLCanvasElement && (t.onclick = function(t) {
                var e = n.getElementsAtEventForMode(t, "point", n.options);
                try {
                    if ($$$DEBUG && (console.log(t), console.log(t.srcElement.id)), !e) return;
                    var r = e[0];
                    if (!r) return;
                    var i = n.data.labels[r._index],
                        c = n.data.datasets[r._datasetIndex].data[r._index],
                        s = n.data.datasets[r._datasetIndex].label,
                        l = n.options.title.text;
                    o(t.srcElement.id, i, c, s, l)
                } catch (t) {
                    return console.log(a + "\n if(_canvas instanceof HTMLCanvasElement)  22; \n" + t.name + "\n" + t.message), !1
                }
            })
        }, r.loadReport = function(n, o) {
            var s = this;
            s.options = null, s._init = function() {
                try {
                    s.options = t.extend(!0, {}, rep_defaults, n), o = o || r.chart_config
                } catch (t) {
                    return console.log(a + "\n _self._init ($.extend)\n" + t.name + "\n" + t.message), !1
                }
            };
            try {
                s._init()
            } catch (t) {
                return console.log(a + "\n _self._init()\n" + ce.name + "\n" + t.message), !1
            }
            var l = function(n, o) {
                    var e = "",
                        a = [];
                    return t.each(n, function(t, o) {
                        "string" == typeof o && a.push([JSON.stringify(o)]), "object" == typeof o && (a = n)
                    }), t.each(a, function(t, n) {
                        Object.keys(n).forEach(function(t) {
                            t == o && (e += "," + n[t])
                        })
                    }), (e = e.replace(/^,/, "")).split(",")
                },
                f = function(n, o) {
                    var e = "",
                        a = [];
                    return t.each(n, function(t, o) {
                        "string" == typeof o && a.push([JSON.stringify(o)]), "object" == typeof o && (a = n)
                    }), t.each(a, function(t, n) {
                        Object.keys(n).forEach(function(t) {
                            t == o && (e += "," + n[t])
                        })
                    }), (e = e.replace(/^,/, "")).split(",").filter(c)
                },
                p = function(n, o, e, r) {
                    var i = [],
                        c = 0;
                    t.each(n, function(t, o) {
                        "string" == typeof o && i.push([JSON.stringify(o)]), "object" == typeof o && (i = n)
                    });
                    try {
                        t.each(i, function(t, n) {
                            n[e] == o && (c += +n[r])
                        })
                    } catch (t) {
                        return console.log(a + "\n chart_data = function(_d) \n" + t.name + "\n" + t.message), o
                    }
                    return o + " (" + c + ")"
                },
                u = function(n, o, e, a, r, i) {
                    var c = [],
                        s = [],
                        l = 0;
                    t.each(n, function(t, o) {
                        "string" == typeof o && c.push([JSON.stringify(o)]), "object" == typeof o && (c = n)
                    });
                    for (var f = 0; f < i.length; f++) l = 0, t.each(c, function(t, n) {
                        i[f] == n[r] && n[o] == e && (l += +n[a])
                    }), s.push(l);
                    return s
                };
            try {
                var d, h;
                "function" == typeof e && e.destroy(), t("#chart-" + s.options.report_name).remove(), t("#container-" + s.options.report_name).remove(), t("#report-container-normal-").append('<div id="container-' + s.options.report_name + '" class="-container-big-" title="+' + s.options.report_name + '"> </div>'), t("#container-" + s.options.report_name).append('<canvas id="chart-' + s.options.report_name + '" class = "-chart-normal-"><canvas>'), h = document.querySelector("#chart-" + s.options.report_name), d = h.getContext("2d"), t("#container-" + s.options.report_name).prop("title", s.options.chart_title), $$$DEBUG && console.log(h), (e = new i(d, {
                    type: s.options.type,
                    data: function(t, n, o, e) {
                        var r, i = [];
                        e.length > 0 ? r = function(t, n, o, e, a) {
                            for (var r = [], i = f(t, e), c = 0; c < i.length; c++)
                                if ("null" != i[c]) {
                                    var s = randomColor();
                                    r.push({
                                        label: p(t, i[c], e, o[0]),
                                        data: u(t, e, i[c], o[0], n, a),
                                        fill: !1,
                                        borderColor: s,
                                        backgroundColor: s,
                                        pointBorderWidth: 5,
                                        pointHoverRadius: 8,
                                        hoverBackgroundColor: "#ffffff",
                                        borderWidth: 3,
                                        pointBackgroundColor: "#ffffff"
                                    })
                                }
                            return r
                        }(t, n, o, e, i = f(t, n)) : (i = l(t, n), r = function(t, n) {
                            for (var o = [], e = 0; e < n.length; e++) {
                                var a = randomColor();
                                o.push({
                                    label: n[e],
                                    data: l(t, n[e]),
                                    fill: !1,
                                    fill: !1,
                                    borderColor: a,
                                    backgroundColor: a,
                                    pointBorderWidth: 5,
                                    pointHoverRadius: 8,
                                    hoverBackgroundColor: "#ffffff",
                                    borderWidth: 3,
                                    pointBackgroundColor: "#ffffff"
                                })
                            }
                            return o
                        }(t, o));
                        try {
                            return {
                                labels: i,
                                datasets: r
                            }
                        } catch (t) {
                            return console.log(a + "\n chart_data = function(_d) \n" + t.name + "\n" + t.message), !1
                        }
                    }(s.options.data_chart, s.options.Xname, s.options.Yname, s.options.YnameAsValue),
                    options: r.chart_config(s.options.allTips, s.options.chart_title),
                    onClick: function(t) {}
                })).update(), r.bind_click_canvas_chart(h, e, s.options.point_fnc)
            } catch (t) {
                return console.log(a + "\n  self.loadReport 11; \n" + t.name + "\n" + t.message), !1
            }
        }
    } catch (t) {
        return console.log(a + "\n  try { 48;; \n" + t.name + "\n" + t.message), !1
    }
    return r
});