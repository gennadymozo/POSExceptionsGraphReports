<?php
    $server = 'localhost';
    $user = 'root';
    $pass = '';
    $dbase = 'assetmgmt';
//  START-------------------------------------------------------------------------------------------------------
            function fetch($result){
                $array = array();
                if($result instanceof mysqli_stmt){
                    $result->store_result();
                    $variables = array();
                    $data = array();
                    $meta = $result->result_metadata();
                    while($field = $meta->fetch_field()){$variables[] = &$data[$field->name];}
                    call_user_func_array(array($result, 'bind_result'), $variables);
                    $i = 0;
                    while($result->fetch()){
                        $array[$i] = array();
                        foreach($data as $k => $v){$array[$i][$k] = $v;}
                        $i++;
                    }
                }elseif($result instanceof mysqli_result){
                    while($row = $result->fetch_assoc())
                        $array[] = $row;
                }
                return ($array);
            }
            //  -------------------------------------------------------------------------------------------------------
            //  !  at least one parameter must be specified  !  ! dont forget: sequences of parameters !
            function prepared_tsql($con, $query, $type = "", $param = array()){
                if($stmt = mysqli_prepare($con, $query)){
                    $refarg = array($stmt, $type);  //  first two parameter of mysqli_stmt_bind_param
                    foreach($param as $key => $value){$refarg[] =& $param[$key];}  //  create array of parameters' references
                    if($type != ""){
                        call_user_func_array("mysqli_stmt_bind_param", $refarg); // bind parameters with dinamic length - if argument $type is missing  ( ! it's not gonna happen - params type is required ! )
                    }
                    //  check if execution go fine
                    if(mysqli_stmt_execute($stmt)){
                        $cols = mysqli_field_count($con);  //  retrive the number of columns of the resultset
                        $result = array_fill(0, $cols, NULL);  //  create an empty array with the same length of the columns
                        $ref = array($stmt);  //  first argument of mysqli_stmt_bind_result
                        foreach($result as $key => $value){$ref[] =& $result[$key];}  //  create array of empty cells' references
                        call_user_func_array("mysqli_stmt_bind_result", $ref);  //  bind results with dinamic length
                        return ($ref); // return statement and columns references
                    }
                    else{return(false);}
                }
                else{ return(false);}
            }  //    statement reference prepared_tsql[0] and columns references prepared_tsql[1]
            //  -------------------------------------------------------------------------------------------------------
            function err2json($err_num = 0, $err_desc = ''){return ('{"error":[{"err_num":"' . $err_num . '","err_desc":"' . $err_desc . '"}]}');}
            //  ----------------------------------------------------------------------------------------
            function str2json($_name,$_name_sub,$_str){return ('{"'.$_name.'":[{"'.$_name_sub.'":"' . $_str . '"}]}');}
//  END-------------------------------------------------------------------------------------------------------




//  function err2json($err_num = 0, $err_desc = ''){return ('{"error":[{"err_num":"' . $err_num . '","err_desc":"' . $err_desc . '"}]}');}