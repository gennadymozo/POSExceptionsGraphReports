<?php
//  START-------------------------------------------------------------------------------------------------------//  START-------------------------------------------------------------------------------------------------------
$test = array("sp_name" => "call sp_node(?,?)", "param_types" => "is");
$stat = array("sp_name" => "call sp_stat(?,?,?,?,?,?,?,?,?)", "param_types" => "iisiissss");

$v_paramsAA = array("sp_name" => "call sp_v_params(?,?,?,?,?,?,?,?,?,?,?)", "param_types" => "iisisssssis");


// next
$sp_users = array("sp_name" => "call sp_users(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", "param_types" => "iissssssssssssss");

//  --  --  ++  ++  ++
//  !! I interface for all:
//  "action":"","id":"","ts":"","active":"","isdefault":"",name:"","description":"","date_inserted":"","date_updated":""
//  array("sp_name" => "call sp_assets(?,?,?,?,?,?,?,?   ...   "param_types" => "iisissss




$v_params = array("sp_name" => "call sp_v_params(?,?,?,?,?,?,?,?,?,?,?)", "param_types" => "iisisssssis");
$config_assets_type = array("sp_name" => "call sp_assets_type(?,?,?,?,?,?,?,?,?)", "param_types" => "iisisssss");
$config_v_params = array("sp_name" => "call sp_v_params(?,?,?,?,?,?,?,?,?,?,?)", "param_types" => "iisisssssis");
$assets = array("sp_name" => "call sp_assets(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", "param_types" => "iisissssssissss");
$locations = array("sp_name" => "call sp_locations(?,?,?,?,?,?,?,?,?,?)", "param_types" => "iisissssss");



//  -------------------------------------------------------------------------------------------------------
$meta_map = array('users' => $sp_users, 'test' => $test, 'stat' => $stat
    ,'v_params' => $v_params, "assets" => $assets, 'config_assets_type' => $config_assets_type
    , 'config_v_params' => $config_v_params, 'locations' => $locations);






//  END-------------------------------------------------------------------------------------------------------//  END-------------------------------------------------------------------------------------------------------