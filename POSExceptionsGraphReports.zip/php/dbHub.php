<?php
include './db_support/db_util.php';
include './db_support/meta_map.php';
$mysqli;
define("MYSQL_CONN_ERROR", "Unable to connect to database");   //  mysqli_report(MYSQLI_REPORT_ALL ^ MYSQLI_REPORT_STRICT);
//  START-------------------------------------------------------------------------------------------------------//  START-------------------------------------------------------------------------------------------------------
try{
$err_num_source = 1;
        //  -------------------------------------------------------------------------------------------------------
                $err_num_source = 2;
                    if((isset($_POST["service"]) && !empty($_POST["service"])) && (isset($_POST["method"]) && !empty($_POST["method"])) && (isset($_POST["parameters"]) && !empty($_POST["parameters"]))){
                        $service = $_POST["service"];
                        $method = $_POST["method"];
                        $parameters =  $_POST["parameters"];
                    }else{
                        echo err2json($err_num_source,'incorrect: service / method / parameters ... (must be supplied) \n');
                        exit();
                    }
        //  --------------------------------------------------------------------------------------------------------
                $err_num_source = 3;
                    try {
                            $mysqli = new mysqli($server, $user, $pass, $dbase);
                        } catch (Exception $e) {
                            echo err2json($err_num_source,'  ( err_num_source: '.$err_num_source.')\n' .MYSQL_CONN_ERROR. '\n   user:  '.$user. '\n   pwd:  '.$pass. '\n   database:  '.$dbase. '\n   host:  '.$server.'\n');
                            exit();
                    }
        //  -------------------------------------------------------------------------------------------------------
                function exec_switch($service = '', $method = '', $p = array()){
                $err_num_source = 4;
                    try{
                        $call = prepared_tsql($GLOBALS['mysqli'], $query = $GLOBALS['meta_map'][$method]['sp_name'], $type = $GLOBALS['meta_map'][$method]['param_types'], $param = $p)[0];
                        if ($call == null){
                            echo err2json($err_num_source,'  ( err_num_source: '.$err_num_source.')\n $call = prepared_tsql\n ($call == null)\n');
                            exit();
                        }
                    return (fetch($call));
                    }catch (Exception $e) {
                        echo err2json($err_num_source,'  ( err_num_source: '.$err_num_source.')\n'.$e->errorMessage().'\n');
                        exit();
                    }
                }
        //  -------------------------------------------------------------------------------------------------------
                $err_num_source = 5;
                    try{
                            $param_arr = array();
                            $param_arr = json_decode(str_replace('\"', '"', $parameters), true);
                            $re = exec_switch($service, $method, $param_arr);
                            echo '{"data":' . json_encode($re) . '}';
                    exit();
                    }catch (Exception $e){
                        echo err2json($err_num_source,'  ( err_num_source: '.$err_num_source.')\n'.$e->errorMessage().'\n');
                        exit();
                    }
exit();
}catch (Exception $e){
    echo err2json($err_num_source,'  ( err_num_source: '.$err_num_source.')\n UNKNOWN ERROR OCCURRED \n');
    exit();
}
//  END-------------------------------------------------------------------------------------------------------//  END-------------------------------------------------------------------------------------------------------


/*
{
   "dataType": "json",
   "data": {
      "service": "proc",
      "method": "stat",
      "parameters": {
         "action": 2,
         "id": 2,
         "ts": "TBLSTAT1458756510408",
         "active": 1,
         "isdefault": 1,
         "name": "second here",
         "description": "ok ?! -- ok..ok... Don't Cry For Me Argentina -",
         "date_created": "0000-00-00",
         "date_updated": "0000-00-00"
      },
      "pkid": -1,
      "action": 0,
      "table": "",
      "metadata": 0
   },
   "url": "../php/dbHub.php",
   "type": "POST",
   "async": true
}
 */